﻿namespace QLTV
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sửaĐọcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SuaDocGiacs SuaDocGiacsform = new SuaDocGiacs();
            SuaDocGiacsform.Show();
        }

        private void quảnLýSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void đổiMậtKhẩuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DoiMatKhau DoiMatKhauform = new DoiMatKhau();
            DoiMatKhauform.Show();
        }

        private void tÌmKiếmSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TimKiemSach TimKiemSachform = new TimKiemSach();
            TimKiemSachform.Show();
        }

        private void thêmSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ThemSach ThemSachform = new ThemSach();
            ThemSachform.Show();
        }

        private void sửaSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SuaSach SuaSachform = new SuaSach();
            SuaSachform.Show();
        }

        private void thêmĐộcGiảToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ThemDocGIa ThemDocGIaform = new ThemDocGIa();
            ThemDocGIaform.Show();
        }

        private void xóaĐộcGiảToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XoaDocGia XoaDocGiaform = new XoaDocGia();
            XoaDocGiaform.Show();
        }

        private void lịchSửMượnSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void thêmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ThemNhanVien ThemNhanVienform = new ThemNhanVien();
            ThemNhanVienform.Show();
        }

        private void mượnSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuonSach MuonSachform = new MuonSach();
            MuonSachform.Show();
        }

        private void trảSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TraSach TraSachform = new TraSach();
            TraSachform.Show();
        }

        private void sốLượngSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SoLuongSach SoLuongSachform = new SoLuongSach();
            SoLuongSachform.Show();
        }

        private void mượnTrảToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuonTraSach MuonTraSachform = new MuonTraSach();
            MuonTraSachform.Show();
        }

        private void sáchQuáHạnToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SachQuaHan SachQuaHanform = new SachQuaHan();
            SachQuaHanform.Show();
        }

        private void quảnLíSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QuanLiSach QuanLiSachform = new QuanLiSach();
            QuanLiSachform.Show();
        }

        private void sửaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SuaNhanVien SuaNhanVienform = new SuaNhanVien();
            SuaNhanVienform.Show();
        }

        private void xóaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XoaNhanVien XoaNhanVienform = new XoaNhanVien();
            XoaNhanVienform.Show();
        }

        private void phânQuyềnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PhanQuyen PhanQuyenform = new PhanQuyen();
            PhanQuyenform.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DangKi DangKiform = new DangKi();
            DangKiform.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DangNhap DangNhapform = new DangNhap();
            DangNhapform.Show();
        }
    }
}
