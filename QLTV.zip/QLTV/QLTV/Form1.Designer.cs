﻿namespace QLTV
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            quảnLýSáchToolStripMenuItem = new ToolStripMenuItem();
            tÌmKiếmSáchToolStripMenuItem = new ToolStripMenuItem();
            thêmSáchToolStripMenuItem = new ToolStripMenuItem();
            sửaSáchToolStripMenuItem = new ToolStripMenuItem();
            quảnLíSáchToolStripMenuItem = new ToolStripMenuItem();
            quảnLýĐộcGiảToolStripMenuItem = new ToolStripMenuItem();
            thêmĐộcGiảToolStripMenuItem = new ToolStripMenuItem();
            sửaĐọcToolStripMenuItem = new ToolStripMenuItem();
            xóaĐộcGiảToolStripMenuItem = new ToolStripMenuItem();
            quảnLýMượnTrảSáchToolStripMenuItem = new ToolStripMenuItem();
            mượnSáchToolStripMenuItem = new ToolStripMenuItem();
            trảSáchToolStripMenuItem = new ToolStripMenuItem();
            thốngKêToolStripMenuItem = new ToolStripMenuItem();
            sốLượngSáchToolStripMenuItem = new ToolStripMenuItem();
            mượnTrảToolStripMenuItem = new ToolStripMenuItem();
            sáchQuáHạnToolStripMenuItem1 = new ToolStripMenuItem();
            nhânViênToolStripMenuItem = new ToolStripMenuItem();
            thêmNVToolStripMenuItem = new ToolStripMenuItem();
            thêmToolStripMenuItem = new ToolStripMenuItem();
            sửaToolStripMenuItem = new ToolStripMenuItem();
            xóaToolStripMenuItem = new ToolStripMenuItem();
            phânQuyềnToolStripMenuItem = new ToolStripMenuItem();
            hệThốngToolStripMenuItem = new ToolStripMenuItem();
            đổiMậtKhẩuToolStripMenuItem = new ToolStripMenuItem();
            đặngSToolStripMenuItem = new ToolStripMenuItem();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            pictureBox2 = new PictureBox();
            pictureBox4 = new PictureBox();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { quảnLýSáchToolStripMenuItem, quảnLýĐộcGiảToolStripMenuItem, quảnLýMượnTrảSáchToolStripMenuItem, thốngKêToolStripMenuItem, nhânViênToolStripMenuItem, hệThốngToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // quảnLýSáchToolStripMenuItem
            // 
            quảnLýSáchToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { tÌmKiếmSáchToolStripMenuItem, thêmSáchToolStripMenuItem, sửaSáchToolStripMenuItem, quảnLíSáchToolStripMenuItem });
            quảnLýSáchToolStripMenuItem.Name = "quảnLýSáchToolStripMenuItem";
            quảnLýSáchToolStripMenuItem.Size = new Size(110, 24);
            quảnLýSáchToolStripMenuItem.Text = "Quản Lý Sách";
            quảnLýSáchToolStripMenuItem.Click += quảnLýSáchToolStripMenuItem_Click;
            // 
            // tÌmKiếmSáchToolStripMenuItem
            // 
            tÌmKiếmSáchToolStripMenuItem.Name = "tÌmKiếmSáchToolStripMenuItem";
            tÌmKiếmSáchToolStripMenuItem.Size = new Size(186, 26);
            tÌmKiếmSáchToolStripMenuItem.Text = "TÌm kiếm sách";
            tÌmKiếmSáchToolStripMenuItem.Click += tÌmKiếmSáchToolStripMenuItem_Click;
            // 
            // thêmSáchToolStripMenuItem
            // 
            thêmSáchToolStripMenuItem.Name = "thêmSáchToolStripMenuItem";
            thêmSáchToolStripMenuItem.Size = new Size(186, 26);
            thêmSáchToolStripMenuItem.Text = "Thêm sách";
            thêmSáchToolStripMenuItem.Click += thêmSáchToolStripMenuItem_Click;
            // 
            // sửaSáchToolStripMenuItem
            // 
            sửaSáchToolStripMenuItem.Name = "sửaSáchToolStripMenuItem";
            sửaSáchToolStripMenuItem.Size = new Size(186, 26);
            sửaSáchToolStripMenuItem.Text = "sửa sách";
            sửaSáchToolStripMenuItem.Click += sửaSáchToolStripMenuItem_Click;
            // 
            // quảnLíSáchToolStripMenuItem
            // 
            quảnLíSáchToolStripMenuItem.Name = "quảnLíSáchToolStripMenuItem";
            quảnLíSáchToolStripMenuItem.Size = new Size(186, 26);
            quảnLíSáchToolStripMenuItem.Text = "quản lí sách";
            quảnLíSáchToolStripMenuItem.Click += quảnLíSáchToolStripMenuItem_Click;
            // 
            // quảnLýĐộcGiảToolStripMenuItem
            // 
            quảnLýĐộcGiảToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { thêmĐộcGiảToolStripMenuItem, sửaĐọcToolStripMenuItem, xóaĐộcGiảToolStripMenuItem });
            quảnLýĐộcGiảToolStripMenuItem.Name = "quảnLýĐộcGiảToolStripMenuItem";
            quảnLýĐộcGiảToolStripMenuItem.Size = new Size(132, 24);
            quảnLýĐộcGiảToolStripMenuItem.Text = "Quản Lý Độc Giả";
            // 
            // thêmĐộcGiảToolStripMenuItem
            // 
            thêmĐộcGiảToolStripMenuItem.Name = "thêmĐộcGiảToolStripMenuItem";
            thêmĐộcGiảToolStripMenuItem.Size = new Size(186, 26);
            thêmĐộcGiảToolStripMenuItem.Text = "Thêm Độc Giả";
            thêmĐộcGiảToolStripMenuItem.Click += thêmĐộcGiảToolStripMenuItem_Click;
            // 
            // sửaĐọcToolStripMenuItem
            // 
            sửaĐọcToolStripMenuItem.Name = "sửaĐọcToolStripMenuItem";
            sửaĐọcToolStripMenuItem.Size = new Size(186, 26);
            sửaĐọcToolStripMenuItem.Text = "Sửa Độc Giả";
            sửaĐọcToolStripMenuItem.Click += sửaĐọcToolStripMenuItem_Click;
            // 
            // xóaĐộcGiảToolStripMenuItem
            // 
            xóaĐộcGiảToolStripMenuItem.Name = "xóaĐộcGiảToolStripMenuItem";
            xóaĐộcGiảToolStripMenuItem.Size = new Size(186, 26);
            xóaĐộcGiảToolStripMenuItem.Text = "Xóa Độc Giả";
            xóaĐộcGiảToolStripMenuItem.Click += xóaĐộcGiảToolStripMenuItem_Click;
            // 
            // quảnLýMượnTrảSáchToolStripMenuItem
            // 
            quảnLýMượnTrảSáchToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { mượnSáchToolStripMenuItem, trảSáchToolStripMenuItem });
            quảnLýMượnTrảSáchToolStripMenuItem.Name = "quảnLýMượnTrảSáchToolStripMenuItem";
            quảnLýMượnTrảSáchToolStripMenuItem.Size = new Size(179, 24);
            quảnLýMượnTrảSáchToolStripMenuItem.Text = "Quản Lý Mượn/Trả Sách";
            // 
            // mượnSáchToolStripMenuItem
            // 
            mượnSáchToolStripMenuItem.Name = "mượnSáchToolStripMenuItem";
            mượnSáchToolStripMenuItem.Size = new Size(166, 26);
            mượnSáchToolStripMenuItem.Text = "Mượn Sách";
            mượnSáchToolStripMenuItem.Click += mượnSáchToolStripMenuItem_Click;
            // 
            // trảSáchToolStripMenuItem
            // 
            trảSáchToolStripMenuItem.Name = "trảSáchToolStripMenuItem";
            trảSáchToolStripMenuItem.Size = new Size(166, 26);
            trảSáchToolStripMenuItem.Text = "Trả Sách";
            trảSáchToolStripMenuItem.Click += trảSáchToolStripMenuItem_Click;
            // 
            // thốngKêToolStripMenuItem
            // 
            thốngKêToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { sốLượngSáchToolStripMenuItem, mượnTrảToolStripMenuItem, sáchQuáHạnToolStripMenuItem1 });
            thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            thốngKêToolStripMenuItem.Size = new Size(86, 24);
            thốngKêToolStripMenuItem.Text = "Thống Kê";
            // 
            // sốLượngSáchToolStripMenuItem
            // 
            sốLượngSáchToolStripMenuItem.Name = "sốLượngSáchToolStripMenuItem";
            sốLượngSáchToolStripMenuItem.Size = new Size(190, 26);
            sốLượngSáchToolStripMenuItem.Text = "Số Lượng Sách";
            sốLượngSáchToolStripMenuItem.Click += sốLượngSáchToolStripMenuItem_Click;
            // 
            // mượnTrảToolStripMenuItem
            // 
            mượnTrảToolStripMenuItem.Name = "mượnTrảToolStripMenuItem";
            mượnTrảToolStripMenuItem.Size = new Size(190, 26);
            mượnTrảToolStripMenuItem.Text = "Mượn / Trả";
            mượnTrảToolStripMenuItem.Click += mượnTrảToolStripMenuItem_Click;
            // 
            // sáchQuáHạnToolStripMenuItem1
            // 
            sáchQuáHạnToolStripMenuItem1.Name = "sáchQuáHạnToolStripMenuItem1";
            sáchQuáHạnToolStripMenuItem1.Size = new Size(190, 26);
            sáchQuáHạnToolStripMenuItem1.Text = "Sách Quá Hạn";
            sáchQuáHạnToolStripMenuItem1.Click += sáchQuáHạnToolStripMenuItem1_Click;
            // 
            // nhânViênToolStripMenuItem
            // 
            nhânViênToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { thêmNVToolStripMenuItem, phânQuyềnToolStripMenuItem });
            nhânViênToolStripMenuItem.Name = "nhânViênToolStripMenuItem";
            nhânViênToolStripMenuItem.Size = new Size(91, 24);
            nhânViênToolStripMenuItem.Text = "Nhân Viên";
            // 
            // thêmNVToolStripMenuItem
            // 
            thêmNVToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { thêmToolStripMenuItem, sửaToolStripMenuItem, xóaToolStripMenuItem });
            thêmNVToolStripMenuItem.Name = "thêmNVToolStripMenuItem";
            thêmNVToolStripMenuItem.Size = new Size(170, 26);
            thêmNVToolStripMenuItem.Text = "Nhân Viên";
            // 
            // thêmToolStripMenuItem
            // 
            thêmToolStripMenuItem.Name = "thêmToolStripMenuItem";
            thêmToolStripMenuItem.Size = new Size(129, 26);
            thêmToolStripMenuItem.Text = "Thêm";
            thêmToolStripMenuItem.Click += thêmToolStripMenuItem_Click;
            // 
            // sửaToolStripMenuItem
            // 
            sửaToolStripMenuItem.Name = "sửaToolStripMenuItem";
            sửaToolStripMenuItem.Size = new Size(129, 26);
            sửaToolStripMenuItem.Text = "Sửa";
            sửaToolStripMenuItem.Click += sửaToolStripMenuItem_Click;
            // 
            // xóaToolStripMenuItem
            // 
            xóaToolStripMenuItem.Name = "xóaToolStripMenuItem";
            xóaToolStripMenuItem.Size = new Size(129, 26);
            xóaToolStripMenuItem.Text = "Xóa";
            xóaToolStripMenuItem.Click += xóaToolStripMenuItem_Click;
            // 
            // phânQuyềnToolStripMenuItem
            // 
            phânQuyềnToolStripMenuItem.Name = "phânQuyềnToolStripMenuItem";
            phânQuyềnToolStripMenuItem.Size = new Size(170, 26);
            phânQuyềnToolStripMenuItem.Text = "Phân Quyền";
            phânQuyềnToolStripMenuItem.Click += phânQuyềnToolStripMenuItem_Click;
            // 
            // hệThốngToolStripMenuItem
            // 
            hệThốngToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { đổiMậtKhẩuToolStripMenuItem, đặngSToolStripMenuItem });
            hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            hệThốngToolStripMenuItem.Size = new Size(88, 24);
            hệThốngToolStripMenuItem.Text = "Hệ Thống";
            // 
            // đổiMậtKhẩuToolStripMenuItem
            // 
            đổiMậtKhẩuToolStripMenuItem.Name = "đổiMậtKhẩuToolStripMenuItem";
            đổiMậtKhẩuToolStripMenuItem.Size = new Size(183, 26);
            đổiMậtKhẩuToolStripMenuItem.Text = "Đổi Mật Khẩu";
            đổiMậtKhẩuToolStripMenuItem.Click += đổiMậtKhẩuToolStripMenuItem_Click;
            // 
            // đặngSToolStripMenuItem
            // 
            đặngSToolStripMenuItem.Name = "đặngSToolStripMenuItem";
            đặngSToolStripMenuItem.Size = new Size(183, 26);
            đặngSToolStripMenuItem.Text = "Đăng Xuất";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.pngtree_online_library_digital_education_background_with_distance_learning_png_image_5083826;
            pictureBox1.Location = new Point(12, 31);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(800, 407);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ActiveCaption;
            button1.Location = new Point(528, 45);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 2;
            button1.Text = "Đăng Kí";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ActiveCaption;
            button2.Location = new Point(676, 45);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 3;
            button2.Text = "Đăng Nhập";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.dang_ky;
            pictureBox2.Location = new Point(492, 45);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(30, 29);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.dang_nhap;
            pictureBox4.Location = new Point(640, 45);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(30, 29);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 6;
            pictureBox4.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox2);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(menuStrip1);
            Controls.Add(pictureBox1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem quảnLýSáchToolStripMenuItem;
        private ToolStripMenuItem tÌmKiếmSáchToolStripMenuItem;
        private ToolStripMenuItem thêmSáchToolStripMenuItem;
        private ToolStripMenuItem sửaSáchToolStripMenuItem;
        private ToolStripMenuItem quảnLíSáchToolStripMenuItem;
        private ToolStripMenuItem quảnLýĐộcGiảToolStripMenuItem;
        private ToolStripMenuItem thêmĐộcGiảToolStripMenuItem;
        private ToolStripMenuItem sửaĐọcToolStripMenuItem;
        private ToolStripMenuItem xóaĐộcGiảToolStripMenuItem;
        private ToolStripMenuItem quảnLýMượnTrảSáchToolStripMenuItem;
        private ToolStripMenuItem mượnSáchToolStripMenuItem;
        private ToolStripMenuItem trảSáchToolStripMenuItem;
        private ToolStripMenuItem thốngKêToolStripMenuItem;
        private ToolStripMenuItem sốLượngSáchToolStripMenuItem;
        private ToolStripMenuItem mượnTrảToolStripMenuItem;
        private ToolStripMenuItem sáchQuáHạnToolStripMenuItem1;
        private ToolStripMenuItem nhânViênToolStripMenuItem;
        private ToolStripMenuItem thêmNVToolStripMenuItem;
        private ToolStripMenuItem phânQuyềnToolStripMenuItem;
        private ToolStripMenuItem hệThốngToolStripMenuItem;
        private ToolStripMenuItem đổiMậtKhẩuToolStripMenuItem;
        private ToolStripMenuItem đặngSToolStripMenuItem;
        private PictureBox pictureBox1;
        private ToolStripMenuItem thêmToolStripMenuItem;
        private ToolStripMenuItem sửaToolStripMenuItem;
        private ToolStripMenuItem xóaToolStripMenuItem;
        private Button button1;
        private Button button2;
        private PictureBox pictureBox2;
        private PictureBox pictureBox4;
    }
}
