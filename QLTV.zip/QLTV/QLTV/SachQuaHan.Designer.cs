﻿namespace QLTV
{
    partial class SachQuaHan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            dateTimePicker1 = new DateTimePicker();
            label5 = new Label();
            label1 = new Label();
            listView1 = new ListView();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(350, 189);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 56;
            button2.Text = "Kiểm tra";
            button2.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(307, 124);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(250, 27);
            dateTimePicker1.TabIndex = 55;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(198, 129);
            label5.Name = "label5";
            label5.Size = new Size(103, 20);
            label5.TabIndex = 52;
            label5.Text = "Ngày Trả Sách";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(307, 43);
            label1.Name = "label1";
            label1.Size = new Size(205, 38);
            label1.TabIndex = 47;
            label1.Text = "Sách Quá Hạn";
            // 
            // listView1
            // 
            listView1.Location = new Point(42, 257);
            listView1.Name = "listView1";
            listView1.Size = new Size(709, 160);
            listView1.TabIndex = 57;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // SachQuaHan
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listView1);
            Controls.Add(button2);
            Controls.Add(dateTimePicker1);
            Controls.Add(label5);
            Controls.Add(label1);
            Name = "SachQuaHan";
            Text = "SachQuaHan";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private DateTimePicker dateTimePicker1;
        private Label label5;
        private Label label1;
        private ListView listView1;
    }
}