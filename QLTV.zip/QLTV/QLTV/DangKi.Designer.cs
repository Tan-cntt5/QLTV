﻿namespace QLTV
{
    partial class DangKi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            label3 = new Label();
            textBox1 = new TextBox();
            comboBox1 = new ComboBox();
            label4 = new Label();
            textBox2 = new TextBox();
            label5 = new Label();
            textBox3 = new TextBox();
            label6 = new Label();
            textBox4 = new TextBox();
            button1 = new Button();
            button3 = new Button();
            label7 = new Label();
            textBox5 = new TextBox();
            pictureBox1 = new PictureBox();
            button2 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(37, 124);
            label2.Name = "label2";
            label2.Size = new Size(56, 20);
            label2.TabIndex = 34;
            label2.Text = "Họ Tên";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(37, 175);
            label3.Name = "label3";
            label3.Size = new Size(68, 20);
            label3.TabIndex = 35;
            label3.Text = "Giới Tính";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(110, 121);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(230, 27);
            textBox1.TabIndex = 36;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(108, 172);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(230, 28);
            comboBox1.TabIndex = 37;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(35, 237);
            label4.Name = "label4";
            label4.Size = new Size(78, 20);
            label4.TabIndex = 38;
            label4.Text = "UserName";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(108, 234);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(230, 27);
            textBox2.TabIndex = 39;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(420, 178);
            label5.Name = "label5";
            label5.Size = new Size(35, 20);
            label5.TabIndex = 40;
            label5.Text = "SDT";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(493, 175);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(230, 27);
            textBox3.TabIndex = 41;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(420, 127);
            label6.Name = "label6";
            label6.Size = new Size(57, 20);
            label6.TabIndex = 42;
            label6.Text = "Địa Chỉ";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(493, 124);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(230, 27);
            textBox4.TabIndex = 43;
            // 
            // button1
            // 
            button1.Location = new Point(337, 313);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 44;
            button1.Text = "LogIn";
            button1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(459, 313);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 45;
            button3.Text = "Close";
            button3.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(420, 240);
            label7.Name = "label7";
            label7.Size = new Size(32, 20);
            label7.TabIndex = 46;
            label7.Text = "PIN";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(493, 237);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(230, 27);
            textBox5.TabIndex = 47;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.ngrgter;
            pictureBox1.Location = new Point(-8, -2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(796, 440);
            pictureBox1.TabIndex = 48;
            pictureBox1.TabStop = false;
            // 
            // button2
            // 
            button2.Location = new Point(217, 313);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 49;
            button2.Text = "Register";
            button2.UseVisualStyleBackColor = true;
            // 
            // DangKi
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(790, 399);
            Controls.Add(button2);
            Controls.Add(textBox5);
            Controls.Add(label7);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(textBox4);
            Controls.Add(label6);
            Controls.Add(textBox3);
            Controls.Add(label5);
            Controls.Add(textBox2);
            Controls.Add(label4);
            Controls.Add(comboBox1);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Name = "DangKi";
            Text = "DangKi";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private Label label3;
        private TextBox textBox1;
        private ComboBox comboBox1;
        private Label label4;
        private TextBox textBox2;
        private Label label5;
        private TextBox textBox3;
        private Label label6;
        private TextBox textBox4;
        private Button button1;
        private Button button3;
        private Label label7;
        private TextBox textBox5;
        private PictureBox pictureBox1;
        private Button button2;
    }
}