﻿namespace QLTV
{
    partial class MuonTraSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dateTimePicker1 = new DateTimePicker();
            button3 = new Button();
            label5 = new Label();
            label1 = new Label();
            listView1 = new ListView();
            button1 = new Button();
            SuspendLayout();
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(303, 114);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(250, 27);
            dateTimePicker1.TabIndex = 44;
            // 
            // button3
            // 
            button3.Location = new Point(419, 366);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 43;
            button3.Text = "Close";
            button3.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(225, 121);
            label5.Name = "label5";
            label5.Size = new Size(72, 20);
            label5.TabIndex = 39;
            label5.Text = "Thời Gian";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(294, 56);
            label1.Name = "label1";
            label1.Size = new Size(219, 38);
            label1.TabIndex = 33;
            label1.Text = "Mượn/Trả Sách";
            // 
            // listView1
            // 
            listView1.Location = new Point(59, 167);
            listView1.Name = "listView1";
            listView1.Size = new Size(695, 166);
            listView1.TabIndex = 45;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // button1
            // 
            button1.Location = new Point(303, 366);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 46;
            button1.Text = "Search";
            button1.UseVisualStyleBackColor = true;
            // 
            // MuonTraSach
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(listView1);
            Controls.Add(dateTimePicker1);
            Controls.Add(button3);
            Controls.Add(label5);
            Controls.Add(label1);
            Name = "MuonTraSach";
            Text = "MuonTraSach";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DateTimePicker dateTimePicker1;
        private Button button3;
        private Label label5;
        private Label label1;
        private ListView listView1;
        private Button button1;
    }
}